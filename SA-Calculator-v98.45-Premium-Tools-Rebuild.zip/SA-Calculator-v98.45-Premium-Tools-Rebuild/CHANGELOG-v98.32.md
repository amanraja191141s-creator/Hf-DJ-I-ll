# SA Calculator v98.32 — change register

## Recording-derived defects addressed

| Defect seen in the 2026-11-17 recordings | v98.32 source treatment |
|---|---|
| Clipped blue pseudo-title/header strips on tool screens | Removed obsolete pseudo toolbar/title rules; only the JS-created toolbar remains |
| Competing currency picker/native Android select popup | Removed old modal markup, functions and select pointer handlers; one unified picker remains |
| Currency picker missing country/region flag, code/name context | Added flag, localized name, ISO code and region on each option and selected control |
| Currency picker Cancel/native dialog behavior | Native select is visually hidden after enhancement; unified picker has one close action and backdrop/Escape dismissal |
| Drawer rows showing duplicate icon columns | Removed pseudo-generated icon column; one authored icon per row |
| Drawer too narrow and cramped | Set responsive 88–90vw width with a 390px maximum |
| Header Settings duplicate action | Hidden/removed from the active header UI; Settings remains in bottom navigation |
| Body Metrics blank white status pill | JS sets the empty status node hidden; CSS removes empty/hidden status geometry |
| Body Metrics empty green result | Empty/incomplete results use neutral navy; success styling only after valid inputs |
| Fuel Cost empty/invalid result styling | Existing hidden result logic reinforced; neutral prompt until successful calculation |
| Fuel Efficiency empty result green panel | Added explicit `data-state` handling for empty, incomplete, error and success |
| Loan suffix overflow | Input and suffix tracks constrained; amortization schedule remains horizontally scrollable |
| Unit Price redundant trophy/check and label mismatch risk | Redundant decorative icons hidden; winner text uses visible Item 1/Item 2 headings |
| World Time oversized globe/hero | Hero and globe dimensions compacted |
| Tool numeric keyboard UI | Shared on-demand keypad remains the single keypad for tools; permanent keypad remains Calculator-only |
| Scientific function panel visual inconsistency | Grouped function panel restyled as a safe-area-aware premium sheet |

## Runtime architecture

- Removed the redundant `#currency-picker-modal` HTML and its `ensureCurrencyPicker`, `openCurrencyPicker`, `closeCurrencyPicker`, and `renderCurrencyPickerList` runtime.
- Removed the currency select pointer handler that raced the custom select enhancement.
- Enhanced the unified Sumaire picker to render currency-specific flags and metadata.
- Preserved the underlying native select as the source of truth for selected code and existing calculation listeners.
- Added Fuel Efficiency result-state transitions in the calculation function.

## Version identity

- `package.json`, `manifest.webmanifest`, HTML metadata, `APP_VERSION`, service-worker cache and Android workflow: `1.98.32-v98.32`
- Android versionCode: `1098032`
