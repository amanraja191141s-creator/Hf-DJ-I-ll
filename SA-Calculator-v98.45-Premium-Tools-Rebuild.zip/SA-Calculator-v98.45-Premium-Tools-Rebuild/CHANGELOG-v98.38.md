# SA Calculator v98.38 — release hardening

- Preserves all 18 source-defined screen IDs and existing calculation/navigation handlers.
- Adds keyboard-visible focus treatment for native selects and action buttons.
- Adds a narrow 320–340px form-containment rule for Android WebViews.
- Requires the v98.38 stylesheet in HTML, service-worker precache, and Android web-bundle generation.
- Synchronizes app version `1.98.38-v98.38`, Android versionCode `1098038`, and workflow copies.
- Renames ES-module tests to `.mjs` and runs both `.js` and `.mjs` tests explicitly to avoid Node mixed-module reparsing warnings.

Hosted APK build and physical-device visual/performance testing remain required before device-level sign-off.
