# Changelog — v98.33

## UI and interaction rebuild
- Added a single authoritative premium design stylesheet loaded after the compatibility/structure layer.
- Unified app header, injected tool toolbar, drawer, bottom navigation, cards, fields, buttons, result states and dialogs.
- Redesigned tool drawer as a searchable categorized tile grid; favorites remain a separate quick-access section.
- Reworked calculator display/keypad, currency and unit converter layouts, scientific modal, settings, favorites, history, loan schedule, world time and all tool form/result surfaces.
- Added small-screen, landscape, light-theme and reduced-motion styling.

## Input behavior
- Currency and Unit Converter no longer show their keypad dock permanently; tapping numeric fields opens the shared keypad.
- Hexadecimal keypad is hidden until a base row is tapped, and closes with Done, Escape or navigation away.
- Text search retains the system text keyboard; date controls retain date-picker behavior.
- Basic Calculator retains its permanent keypad.

## Preserved systems
- Existing calculator expression engine, scientific calculation functions, currency provider/cache layer, unit catalogue, tool calculation engines, storage, localization, history, favorites and settings event handlers remain connected.

## Offline navigation resilience (release hardening)
- Cached app shell is now used when a navigation request receives a transient HTTP 5xx response, not only when the network request rejects.
- Genuine HTTP 4xx responses remain visible and are not silently rewritten as a successful cached app page.
- Added regression coverage for both server-failure fallback and 4xx pass-through behavior.
